<?php

if(isset($_POST['edit'])==true)
{
	print '修正ボタンが押された';
}

if(isset($_POST['delete'])==true)
{
	print '削除ボタンが押された';
}

?>