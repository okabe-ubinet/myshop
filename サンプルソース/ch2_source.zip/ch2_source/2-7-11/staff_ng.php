<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ろくまる農園</title>
</head>
<body>

スタッフが選択されていません。<br />
<a href="staff_list.php">戻る</a>

</body>
</html>